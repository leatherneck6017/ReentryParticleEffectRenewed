# ReentryParticleEffect
This mod activates an unused stock particle effect for reentry, featuring a plasma trail and sparks. 
